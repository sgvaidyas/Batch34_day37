﻿$(document).ready(function () {
    player1 = 1
    player2 = 2
    player = player1
    moves = 1
    //to save the divs clicked by individual player
    ob = {
            "Player1": [],
            "Player2": [] 
    }
    id = 0
    play=true
    $(".mydivs div").click(function () {
        //store the background color of element that you have clicked
        currcolor = $(this).css("background-color")
        if (play == false)
            alert("GAMEOVER")
        else {
            //if currcolor of div that player has clicked is yellow
            if (currcolor == "rgb(255, 255, 0)") {
                if (play) {
                    //this will help us assign the game blocks to player alternatively
                    if (moves % 2 == 1) {
                        alert("Player 1 moves")
                        $(this).css("background-color", "tomato")
                        player = player1  //player=1
                        //the id of the current div is stored in id (string ) "1"
                        id = $(this).attr('id')
                        //converting id to int and storing in array
                        ob.Player1.push(parseInt(id))
                    }
                    else {
                        alert("Player 2 moves")
                        $(this).css("background-color", "green")
                        player = player2
                        id = $(this).attr('id')
                        ob.Player2.push(parseInt(id))
                    }
                    //minimum moves to declare a winner(player1:3) player2 would complete 2 moves hence 5th move is appropriate
                    if (moves >= 5) {
                        res = checkwinner(player)
                        if (res != 0) {
                            $("#player").text("Winner = Player  " + res)
                            play = false
                        }
                    }
                    moves++
                    if (moves == 10) {
                        $("#player").text("No winner")
                        play = false
                    }                        
                }
            }
            else
                alert("Chose some other block")
        }
 
    })
    function checkwinner(player) {
        //condition to store array of the object ob based on key -> Player1 or player2
        //if player==1 -> ob.Player1 otherwise ob.Player2;
        arr = (player == 1) ? ob.Player1 : ob.Player2;
        //possibilities on which he winner will be decided
        //length=8
        conditions = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [1, 4, 7], [2, 5, 8], [3, 6, 9], [1, 5, 9], [7, 5, 3	]]
        // console.log("Array = " + arr)
        flag = false
        for (i = 0; i < conditions.length; i++) {
            //console.log(conditions[i] + "  |   arr = "+ arr)
            //console.log(conditions[i].sort().every(e => arr.sort().includes(e)))
            if (conditions[i].sort().every(e => arr.sort().includes(e))) {
                flag=true
                break;
            }
        }
        if (flag)
            return player;
        else
            return 0;
    }
})